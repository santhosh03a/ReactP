
import './App.css';
import Navbar from './components/navbar';
import {CartProvider} from "react-use-cart";

function App() {
  
  return (
     <div className="App">
       <CartProvider>
        <Navbar/>
      </CartProvider>
   </div>
  );
}

export default App;
