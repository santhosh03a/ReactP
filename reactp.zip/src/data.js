
const data={
    products:[
        {
        id:'1',
        name:'Nike Air Force 1 07',
        price:7500,
        desc:"The radiance lives on in the Nike Air Force 1 '07, the b-ball OG that puts a fresh spin on what you know best.",
        image:'https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/4f37fca8-6bce-43e7-ad07-f57ae3c13142/air-force-1-07-shoe-WrLlWX.png',
        },
        {
            id:'2',
            name:'Nike Dunk High Retro SE',
            price:10000,
            desc:"Go full throttle in the Nike Dunk Low High Retro.It brings motocross-inspired details like bold branding.",
            image:"https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/dee60c30-766a-4bda-a69d-48ac9f884a98/dunk-high-retro-se-shoes-tXRLdK.png",
        },
        {
            id:'3',
            name:'Nike Air Zoom Tempo NEXT%',
            price:17000,
            desc:"While these speedsters could easily pass the test on race day, they double as your go-to shoe for your training routine.",
            image:'https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/e4bfbd80-30ec-447d-82a4-43a8ef0e361b/air-zoom-tempo-next-road-running-shoes-chNfdw.png',
        },
        {
            id:'4',
            name:'Nike SB Chron 2 Canvas',
            price:5000,
            desc:"The Nike SB Chron 2 Canvas is the newest member of the Chron family.The revamped design includes a reshaped collar and heel for an improved fit.",
            image:'https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/a0754b3a-14ba-4948-92f4-8a3184694b92/sb-chron-2-canvas-skate-shoe-zdBtfH.png',
        },
        {
            id:'5',
            name:'rub',
            price:400,
            desc:"Some quick example text to build on the card title and make up the bulk of the card's content.",
            image:'https://guide-images.cdn.ifixit.com/igi/hulYfOgpBDcRmgwa.large',
        },
        {
            id:'6',
            name:'rubix cube',
            price:400,
            desc:"Some quick example text to build on the card title and make up the bulk of the card's content.",
            image:'https://guide-images.cdn.ifixit.com/igi/hulYfOgpBDcRmgwa.large',
        },
        
    ]
}
export default data;